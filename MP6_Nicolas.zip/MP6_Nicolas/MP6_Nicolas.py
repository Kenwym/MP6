text = "BWFWKSAKWFIMWDKWFKDWKHZADGKGHZWKGFLKMHHGKWIMWDSESLAWJWWLSALAFVAXXWJWFLWSMEGMNWEWFLWLSMJWHGKUWIMADQSVWTAWFUWJLSAFUWKLIMWLGMKDWKUGJHKYJSNALWFLDWKMFKKMJDWKSMLJWKUWKLIMWLGMLWKDWKHSJLAUMDWKVWKUGJHKYJSNALWFLDWKMFWKKMJDWKSMLJWKUWKLIMWVSFKUWLMFANWJKLGMLWKLWFLJSFKDSLAGFGMAFFAKMGMWFLJSFKDSLAGFWLAFFAKMSDSXGAKUWLLWKMHHGKALAGFVWKHZADGKGHZWKJWKKWETDWHWMLWLJWSUWDDWVWKYWGEWLJWKIMASVEWLLWFLVWKHGAFLKKSFKSMUMFWVAEWFKAGFVWKDAYFWKKSFKDSJYWMJFAHJGXGFVWMJVWKKMJXSUWKKSFKWHSAKKWMJGMHWMLWLJWHSJDWFLADKVMJWHGKJWDSLAXVMFWESKKWSMFWSMLJWLGMLWKLVSFKMFJWHGKJWDSLAXWFMFNSAKKWSMTSLLMHSJDSLWEHWLWJAWFFQWKLWFMFJWHGKSTKGDMHSKEWEWDWKEGDWUMDWKSYJWYSLANWKFAVMNSAKKWSMFAVWKUGJHKIMADJWFXWJEWKADKFWUGFUGANWFLHSKHDMKVWLWFVSFUWSMJWHGKIMSMEGMNWEWFLVSFKMFUGJHKIMWDUGFIMWUWKLIMSHHSJWEEWFLADKJWYSJVWFLDSESLAWJWUGEEWZGEGYWFWUWKLIMADKXGFLSTKLJSULAGFVWLGMLWKDWKIMSDALWKIMADMAKGFLWKKWFLAWDDWKUWKLIMADKDSUGFKAVWJWFLUGEEWAFSDLWJSTDWVSFKDAFKLSFLHJWKIMWAFVANAKATDWVWDWMJKHWUMDSLAGFUWKLIMADKJSAKGFFWFLVMJWHGKJWDSLAXVMFSYJWYSLSMFSMLJWSYJWYSLUWKLIMADKGMTDAWFLIMWLSFVAKIMADKJSAKGFFWFLVWDAFVAXXWJWFUWVMUGJHKSMEGMNWEWFLGMSMJWHGKDWTDGUVWESJTJWLWFVSKSVAKKGDMLAGFUWKLIMADKSFWSFLAKKWFLHSJDSHWFKWWWLDWEGMNWEWFLYWFWJSDIMASFAEWLGMKDWKUGJHKWLDWMJSULAGFHSJLAUMDAWJWVWKMFKKMJDWKSMLJWKIMADWKVWLJMALLGMKUWKLIMWUWLLWAFVAXXWJWFUWIMGAIMWXSMKKWWFWDDWEWEWESAKEGEWFLSFWWFWJWFVJSHSKDWKDGAKVMEGMNWEWFLWJJGFWWK"
def compter()->dict:
    d = {chr(i+65): 0 for i in range(26)} #Je crée un dictionnaire dont les clés sont les lettres de l'alphabet et les valeurs 0
    total = len(text) 
    for i in text: #pour chaque lettre du texte
        d[i] += 1 # je rajoute 1 à la valeur correspondant à la clé i (une lettre)
    for i in range(26): #pour chaque lettre de l'alphabet
        d[chr(i+65)] /= total # je fais une proportion (nombre d'élément/nombre total)
        d[chr(i+65)] = round(d[chr(i+65)], 2) # j'arrondis le résultat car c'est demandé
    return d

def cesarcle()->dict:
    proportion = compter()#je récupère les proportions de la fonction compter
    x = proportion[chr(65)] # je crée une variable de départ pour qu'il n'y ai pas de problème dans la condition future
    num_lettre = 65 #car l'alphabet commence dans l'unicode commence à 65
    text_traduit = "" # je prépare un variable text pour plus tard
    for i in range(26): #pour chaque lettre de l'alphabet
        if proportion[chr(i+65)] > x: #si la valeur de la clé est plus grande que x
            x = proportion[chr(i+65)] #x est remplacée par cette meme valeur
            num_lettre = i #num_lettre prend la valeur de i, donc la place dans l'alphabet
    # Ce "for i in range" calcule la place de E dans le texte modifié
    cle = 4 - num_lettre #je calcule la clé avec la place de E (4) et la place de E dans le texte modifié
    d = {chr(i+65):chr((i+cle) %26+65) for i in range(26)} # je crée un dictionnaire qui associe les lettres avec un clé
    for i in text:
        text_traduit += str(d.get(i))
    #ce "for i in range" traduit le texte grace au dictionnaire crée juste au dessus
    return text_traduit # on renvoie le texte

print(cesarcle())

    